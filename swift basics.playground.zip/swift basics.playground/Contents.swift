import UIKit
var name = "Haya"
var age = 22
var GPA = 3.5

print("my name is \(name)")
print("I am \(age)")
print("My GPA is  \(GPA)")

var numericString = "10"
if var intValue = Int(numericString),var doubleValue=Double(numericString){
    print("in INT: \(intValue)")
    print("in Double:\(doubleValue)")
    
}
var ageConverted = Double(age)
var gpaConvert = Int(GPA)
print("Age Converted :\(ageConverted)")
print("Gpa Converted :\(gpaConvert)")

var isStudent = true
print("Is Student \(isStudent)")

if age >= 13 && age<=19{
    print("the age is valid")
    
}else{
    print("null age ")
}

if age < 18 || age >= 65 {
    print("eligable for discount")
    
}else{
    print("not eligable for discount")
    
}

func isShorterOrEqualThanFive(text: String) ->Bool {
    return text.count <= 5
    
}

var textTest="haya"
var isShort = isShorterOrEqualThanFive(text: textTest)
print("is it shorter than 5? \(isShort) ")

func convertTocalc(fahrenhiteTemp:Double)->Double{
    return (fahrenhiteTemp - 32)*5/9
    
}
var fahrenhiteTemp = 120.5
var inCalc = convertTocalc(fahrenhiteTemp: fahrenhiteTemp)
print("In Celsius :\(inCalc)C")
